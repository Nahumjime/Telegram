package com.qwe7002.telegram_sms.config;

public class proxy {
    public int port = 1080;
    public String host = "";
    public String username = "";
    public String password = "";
    public boolean enable = false;
    public boolean dns_over_socks5 = true;
}
