package com.qwe7002.telegram_sms.data_structure;

public class sms_request_info {
    public String phone;
    public int card;
}
