package com.qwe7002.telegram_sms;

public class proxy_config {
    public int proxy_port = 1080;
    public String proxy_host = "";
    public String username = "";
    public String password = "";
    public boolean enable = false;
    public boolean dns_over_socks5 = true;
}
