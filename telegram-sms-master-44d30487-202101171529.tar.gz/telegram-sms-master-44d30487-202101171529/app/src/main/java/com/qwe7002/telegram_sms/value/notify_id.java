package com.qwe7002.telegram_sms.value;

public class notify_id {
    public static final int BATTERY = 1;
    public static final int CHAT_COMMAND = 2;
    public static final int NOTIFICATION_LISTENER_SERVICE = 3;
    //public static final int SEND_USSD_SERVCE_NOTIFY_ID = 4;
    public static final int RESEND_SERVICE = 5;
}
